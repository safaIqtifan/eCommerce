package com.example.finalproject.Admin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.finalproject.R

class AdminUserProductsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_user_products)
    }
}
